﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BankingApp.Models.ViewModel
{
    public class PanValidation
    {
        [Required(ErrorMessage = "PAN number is required")]
        [RegularExpression(@"[A-Z]{4}[0-9]{4}", ErrorMessage = "Invalid PAN format")]
        public string C_PAN { get; set; }
    }
}