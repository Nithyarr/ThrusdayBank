﻿using BankModel;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;
using System.Web.Mvc.Routing.Constraints;

namespace BankingApp.Models.ViewModel
{
    public class RegisterViewModel
    {


        [Key]
        public int ID { get; set; }

        public string C_ID { get; set; }

        [Required(ErrorMessage = "Customer name is required")]
        [StringLength(100, ErrorMessage = "Customer name can't be longer than 100 characters")]
        [RegularExpression("^[A-Za-z ]+$", ErrorMessage = "Customer name must contain only letters and spaces")]
        public string C_NAME { get; set; }

        [Required(ErrorMessage = "Date of birth is required")]
        [DataType(DataType.Date)]
        [PastDate(ErrorMessage = "Date must be in the past")]
        public DateTime C_DOB { get; set; }

        [Required(ErrorMessage = "PAN number is required")]
        [RegularExpression(@"[A-Z]{4}[0-9]{4}", ErrorMessage = "Invalid PAN format")]
        public string C_PAN { get; set; }

        [Required(ErrorMessage = "Mobile number is required")]
        [Phone(ErrorMessage = "Invalid mobile number")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Mobile number should be between 10 and 15 digits")]
        public string C_MOBILE { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email address")]
        public string C_EMAIL { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "Salary must be a positive number")]
        public decimal? C_SALARY { get; set; }

        [Required(ErrorMessage = "Address is required")]
        [StringLength(250, ErrorMessage = "Address can't be longer than 250 characters")]
        public string C_ADDRESS { get; set; }

        [Required(ErrorMessage = "Gender is required")]
        [RegularExpression(@"^(Male|Female|Other)$", ErrorMessage = "Gender must be Male, Female, or Other")]
        public string C_GENDER { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [DataType(DataType.Password)]
        [StringLength(100, MinimumLength = 6, ErrorMessage = "Password must be at least 6 characters long")]
        public string C_PASSWORD { get; set; }

        [NotMapped]
        public string SA_ACCOUNT_ID { get; set; }

       
    }
    public class PastDateAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            if (value is DateTime dateValue)
            {
                return dateValue.Date < DateTime.Today;
            }
            return false;
        }
    }
}