﻿using BankingApp.Models.ViewModel;
using BankModel;
using BankModel.ViewModel;
using BankServices;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Services.Description;


namespace BankingApp.Controllers
{
    public class CustomerController : Controller
    {
        private readonly BankDBEntities _dbContext = new BankDBEntities();
        private readonly CustomerService service = new CustomerService();
        private readonly TransactionService _transactionService = new TransactionService();


        public CustomerController()
        {
            _dbContext = new BankDBEntities();
            service = new CustomerService();
            
        }


        [HttpGet]

        public ActionResult CustomerHome()
        {

            if (Session["ReferenceId"] == null)
                return RedirectToAction("Login", "Home");

            string referenceId = Session["ReferenceId"].ToString();
            ViewBag.ReferenceId = referenceId;

            return View();
        }
        [HttpPost]
        public ActionResult CustomerHome(string customerId)
        {
            var customer = _dbContext.Customers.FirstOrDefault(c => c.C_ID == customerId);

            if (customer == null)
            {
                return HttpNotFound("Customer not found");
            }


            ViewBag.Customer = customer;

            return View();
        }

        [HttpGet]
        public ActionResult Deposit()
        {
            
            return View();

        }

        [HttpPost]
        public ActionResult Deposit(decimal amount)
        {

            string id = Session["ReferenceId"].ToString(); 

            ViewBag.ReferenceId = id;
            if (Session["ReferenceId"] == null)
            {
                ViewBag.Message = "Session expired. Please log in again.";
                return View();
            }

            string customerId = Session["ReferenceId"].ToString();
            string result = _transactionService.Deposit(customerId, amount);

            ViewBag.Message = result;
            return View();
        }

        [HttpGet]
        public ActionResult Withdraw()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Withdraw(decimal amount)
        {
            // Check if session exists
            if (Session["ReferenceId"] == null)
            {
                ViewBag.Message = "Session expired. Please log in again.";
                return View();
            }

            string customerId = Session["ReferenceId"].ToString();

            // Fetch customer account first
            var customer = _transactionService.GetCustomerByCId(customerId);
            if (customer == null)
            {
                ViewBag.Message = "Customer not found.";
                return View();
            }

            var account = _transactionService.GetAccountByCustomerId(customer.ID);
            if (account == null)
            {
                ViewBag.Message = "Savings account not found.";
                return View();
            }

            // Check for minimum balance
            if (account.BALANCE - amount < 1000)
            {
                ViewBag.Message = $"Withdrawal failed. Minimum balance of Rs.1000 must be maintained. Current balance: Rs.{account.BALANCE}";
                return View();
            }

            // Perform withdrawal
            string result = _transactionService.Withdraw(customerId, amount);

            ViewBag.Message = result;
            return View();
        }
        [HttpGet]
        public ActionResult TransactionHistory()
        {
            // Check session
            if (Session["ReferenceId"] == null)
            {
                ViewBag.Message = "Session expired. Please log in again.";
                return RedirectToAction("Login", "Account");
            }

            string customerId = Session["ReferenceId"].ToString();

            // Fetch customer
            var customer = _transactionService.GetCustomerByCId(customerId);
            if (customer == null)
            {
                ViewBag.Message = "Customer not found.";
                return View(new List<Savings_Transaction>());
            }

            // Fetch all accounts for this customer
            var accounts = _transactionService.GetAccountsByCustomerId(customer.ID);

            // Fetch all transactions for these accounts
            var transactions = new List<Savings_Transaction>();
            foreach (var account in accounts)
            {
                transactions.AddRange(_transactionService.GetTransactionsByAccountId(account.ID));
            }

            // Order by date descending
            transactions = transactions.OrderByDescending(t => t.ST_TRANSACTION_DATE).ToList();

            return View(transactions);
        }
        //===========================
        //FD ACCOUNT 
        //=======================
        [HttpGet]
        public ActionResult ForecloseFD()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ForecloseFD(string fdAccountId)
        {
            // Session check
            if (Session["ReferenceId"] == null)
            {
                ViewBag.Message = "Session expired. Please log in again.";
                return RedirectToAction("Login", "Account");
            }

            if (string.IsNullOrWhiteSpace(fdAccountId))
            {
                ViewBag.Message = "Please enter FD Account ID.";
                return View();
            }

            string customerId = Session["ReferenceId"].ToString();

            // Call service to foreclose FD for this customer
            string result = _transactionService.ForecloseFDByCustomer(customerId, fdAccountId);

            ViewBag.Message = result;
            return View();
        }
       

        [HttpGet]
        public ActionResult Profile()
        {
            if (Session["ReferenceId"] == null)
            {
                ViewBag.Message = "Session expired. Please log in again.";
                return RedirectToAction("Login", "Account");
            }

            string customerId = Session["ReferenceId"].ToString();
            var customer = _transactionService.GetCustomerByCId(customerId);

            if (customer == null)
            {
                ViewBag.Message = "Customer not found.";
                return View();
            }

            return View(customer);
        }
        [HttpGet]
        public ActionResult CreateFDAccount()
        {
            // Ensure the session is active
            if (Session["ReferenceId"] == null)
            {
                TempData["ErrorMessage"] = "Session expired. Please log in again.";
                return RedirectToAction("Login", "Customer");
            }

            // Fetch Customer ID from session (C00008 → convert to numeric ID)
            string customerIdStr = Session["ReferenceId"].ToString().Replace("C", "");
            int customerId = int.Parse(customerIdStr);

            var model = new FDAccountViewModel
            {
                CustomerId = customerId,
                StartDate = DateTime.Now,
                Status = "Active"
            };

            return View(model);
        }

        [HttpPost]
        public ActionResult CreateFDAccount(FDAccountViewModel model)
        {
            if (Session["ReferenceId"] == null)
            {
                TempData["ErrorMessage"] = "Session expired. Please log in again.";
                return RedirectToAction("Login", "Customer");
            }

            if (!ModelState.IsValid)
            {
                TempData["ErrorMessage"] = "Invalid input.";
                return View(model);
            }

            if (model.Amount < 10000)
            {
                TempData["ErrorMessage"] = "FD amount must be at least ₹10,000.";
                return View(model);
            }

            // Calculate duration from start and end date
            double durationInYears = (model.EndDate - model.StartDate).TotalDays / 365.25;
            if (durationInYears <= 0)
            {
                TempData["ErrorMessage"] = "End Date must be after Start Date.";
                return View(model);
            }

            // Determine interest rate (ROI)
            decimal fdRoi;
            if (durationInYears <= 1)
                fdRoi = 6;
            else if (durationInYears > 1 && durationInYears <= 2)
                fdRoi = 7;
            else
                fdRoi = 8;

            // Fetch customer details
            string customerIdStr = Session["ReferenceId"].ToString().Replace("C", "");
            int customerId = int.Parse(customerIdStr);
            var customer = _dbContext.Customers.Find(customerId);
            if (customer == null)
            {
                TempData["ErrorMessage"] = "Customer not found.";
                return View(model);
            }

            // Add senior citizen benefit
            var age = DateTime.Today.Year - customer.C_DOB.Year;
            if (customer.C_DOB.Date > DateTime.Today.AddYears(-age)) age--;
            if (age >= 60)
                fdRoi += 0.5m;

            model.FdRoi = fdRoi;
            decimal maturityAmount = model.Amount * (1 + (fdRoi / 100));

            // Create FD Account entry
            var fdAccount = new Fixed_Deposit_Account
            {
                C_ID = customerId,
                START_DATE = model.StartDate,
                END_DATE = model.EndDate,
                FD_ROI = fdRoi,
                AMOUNT = model.Amount,
                STATUS = "Active"
            };

            _dbContext.Fixed_Deposit_Account.Add(fdAccount);
            _dbContext.SaveChanges();

            ViewBag.FdRoi = fdRoi;
            ViewBag.MaturityAmount = maturityAmount;
            TempData["SuccessMessage"] = "FD Account created successfully!";
            return View(model);
        }
        //---------------------------------------------
        [HttpGet]
        public ActionResult ViewFDAccounts()
        {
            if (Session["ReferenceId"] == null)
            {
                TempData["ErrorMessage"] = "Session expired. Please log in again.";
                return RedirectToAction("Login", "Customer");
            }

            // Extract customer ID from session
            string customerIdStr = Session["ReferenceId"].ToString().Replace("C", "");
            int customerId = int.Parse(customerIdStr);

            // Get all FDs for that customer
            var fds = _dbContext.Fixed_Deposit_Account
                .Where(fd => fd.C_ID == customerId)
                .ToList();

            return View(fds);
        }
        [HttpGet]
        public ActionResult FDDetails(int id)
        {
            if (Session["ReferenceId"] == null)
            {
                TempData["ErrorMessage"] = "Session expired. Please log in again.";
                return RedirectToAction("Login", "Customer");
            }

            // Find FD account and related transactions
            var fd = _dbContext.Fixed_Deposit_Account
                .FirstOrDefault(f => f.ID == id);

            if (fd == null)
            {
                TempData["ErrorMessage"] = "FD Account not found.";
                return RedirectToAction("ViewFDAccounts");
            }

            var transactions = _dbContext.Fixed_Deposit_Transaction
                .Where(t => t.FT_ACCOUNT_ID == fd.ID)
                .ToList();

            ViewBag.Transactions = transactions;
            return View(fd);
        }




    }
}


    


    
