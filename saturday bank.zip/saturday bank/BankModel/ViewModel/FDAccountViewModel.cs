﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankModel.ViewModel
{
    public class FDAccountViewModel
    {
        [Required]
        public int CustomerId { get; set; }  // Hidden field, links FD to customer

        [Required(ErrorMessage = "Start Date is required")]
        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; }

        [Required(ErrorMessage = "End Date is required")]
        [DataType(DataType.Date)]
        public DateTime EndDate { get; set; }

        [Required(ErrorMessage = "Amount is required")]
        [Range(10000, double.MaxValue, ErrorMessage = "FD amount must be at least ₹10,000")]
        public decimal Amount { get; set; }

        public string Status { get; set; } = "Active";  // Default to Active

        public decimal FdRoi { get; set; }  // Calculated ROI, optional

    }
}
