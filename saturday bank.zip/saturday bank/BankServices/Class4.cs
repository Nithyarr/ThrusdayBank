﻿using BankModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankServices
{
        public class TransactionService
        {
            private readonly BankDBEntities db = new BankDBEntities();

        public string Deposit(string customerIdString, decimal amount)
        {
            if (amount <= 0)
                return "Invalid amount.";

            // Fetch customer by C_ID string
            var customer = db.Customers.FirstOrDefault(c => c.C_ID == customerIdString);
            if (customer == null)
                return "Customer not found.";

            // Fetch the first account for this customer using integer ID
            var account = db.Savings_Account.FirstOrDefault(a => a.C_ID == customer.ID);
            if (account == null)
                return "Savings account not found for this customer.";

            // Update balance
            account.BALANCE += amount;

            // Create transaction
            var transaction = new Savings_Transaction
            {
                ST_TRANSACTION_DATE = DateTime.Now,
                ST_ACCOUNT_ID = account.ID,
                ST_AMOUNT = amount,
                ST_DEPOSIT = amount,
                ST_WITHDRAWL = 0
            };

            db.Savings_Transaction.Add(transaction);
            db.SaveChanges();

            return $"Deposit of Rs.{amount} successful. New balance: {account.BALANCE}";
        }
        public string Withdraw(string customerIdString, decimal amount)
        {
            if (amount <= 0)
                return "Invalid amount.";

            // Fetch customer by C_ID string
            var customer = db.Customers.FirstOrDefault(c => c.C_ID == customerIdString);
            if (customer == null)
                return "Customer not found.";

            // Fetch the first account for this customer
            var account = db.Savings_Account.FirstOrDefault(a => a.C_ID == customer.ID);
            if (account == null)
                return "Savings account not found for this customer.";

            // Check minimum balance (1000)
            if (account.BALANCE - amount < 1000)
                return $"Withdrawal failed. Minimum balance of Rs.1000 must be maintained.";

            // Update balance
            account.BALANCE -= amount;

            // Create transaction
            var transaction = new Savings_Transaction
            {
                ST_TRANSACTION_DATE = DateTime.Now,
                ST_ACCOUNT_ID = account.ID,
                ST_AMOUNT = amount,
                ST_DEPOSIT = 0,
                ST_WITHDRAWL = amount
            };

            db.Savings_Transaction.Add(transaction);
            db.SaveChanges();

            return $"Withdrawal of Rs.{amount} successful. New balance: {account.BALANCE}";
        }
        public Savings_Account GetAccountByCustomerId(int customerId)
        {
            return db.Savings_Account.FirstOrDefault(a => a.C_ID == customerId);
        }
        public Customer GetCustomerByCId(string customerCId)
        {
            if (string.IsNullOrWhiteSpace(customerCId))
                return null;

            var customer = db.Customers.FirstOrDefault(c => c.C_ID == customerCId);
            return customer;
        }
        public List<Savings_Account> GetAccountsByCustomerId(int customerId)
        {
            return db.Savings_Account.Where(a => a.C_ID == customerId).ToList();
        }

        public List<Savings_Transaction> GetTransactionsByAccountId(int accountId)
        {
            return db.Savings_Transaction
                     .Where(t => t.ST_ACCOUNT_ID == accountId)
                     .OrderByDescending(t => t.ST_TRANSACTION_DATE)
                     .ToList();
        }

        public string ForecloseFDByCustomer(string customerCId, string fdAccountIdString)
        {
            if (string.IsNullOrWhiteSpace(customerCId) || string.IsNullOrWhiteSpace(fdAccountIdString))
                return "Invalid request.";

            // Fetch customer
            var customer = db.Customers.FirstOrDefault(c => c.C_ID == customerCId);
            if (customer == null)
                return "Customer not found.";

            // Fetch FD account belonging to this customer
            var fdAccount = db.Fixed_Deposit_Account
                              .FirstOrDefault(f => f.FD_ACCOUNT_ID == fdAccountIdString && f.C_ID == customer.ID);

            if (fdAccount == null)
                return "FD account not found for this customer.";

            if (fdAccount.STATUS == "Closed")
                return "FD account is already closed.";

            // Pre-closure calculation (1% penalty example)
            decimal principal = (decimal)fdAccount.AMOUNT;
            decimal preClosurePenalty = 0.01m * principal; // 1% penalty
            decimal payoutAmount = principal - preClosurePenalty;

            // Update FD account
            fdAccount.STATUS = "Closed";
            fdAccount.END_DATE = DateTime.Now;

            // Log transaction
            var transaction = new Fixed_Deposit_Transaction
            {
                FT_ACCOUNT_ID = fdAccount.ID,
                FT_TRANSACTION_DATE = DateTime.Now,
                FT_AMOUNT = principal,
                FT_PRECLOSURE = payoutAmount
            };

            db.Fixed_Deposit_Transaction.Add(transaction);
            db.SaveChanges();

            return $"FD Account {fdAccount.FD_ACCOUNT_ID} foreclosed successfully. Payout: Rs.{payoutAmount}";
        }


    }
}

        //public class TransactionService
        //{
        //    private readonly BankDBEntities db = new BankDBEntities();


//    // Deposit
//    public string Deposit(int customerId, decimal amount)
//    {
//        if (amount <= 0)
//            return "Invalid amount.";

//        var account = db.Savings_Account.FirstOrDefault(a => a.C_ID == customerId);
//        if (account == null)
//            return $"No Savings Account found for Customer ID: {customerId}";

//        account.BALANCE += amount;

//        var transaction = new Savings_Transaction
//        {
//            ST_TRANSACTION_DATE = DateTime.Now,
//            ST_ACCOUNT_ID = account.ID,
//            ST_AMOUNT = amount,
//            ST_DEPOSIT = amount,
//            ST_WITHDRAWL = 0
//        };

//        db.Savings_Transaction.Add(transaction);
//        db.SaveChanges();

//        return $"Amount of Rs.{amount} deposited successfully for Customer ID {customerId}.";
//    }

//    // Withdraw
//    public string Withdraw(int customerId, decimal amount)
//    {
//        if (amount <= 0)
//            return "Invalid amount.";

//        var account = db.Savings_Account.FirstOrDefault(a => a.C_ID == customerId);
//        if (account == null)
//            return $"No Savings Account found for Customer ID: {customerId}";

//        if (account.BALANCE < amount)
//            return "Insufficient balance.";

//        account.BALANCE -= amount;

//        var transaction = new Savings_Transaction
//        {
//            ST_TRANSACTION_DATE = DateTime.Now,
//            ST_ACCOUNT_ID = account.ID,
//            ST_AMOUNT = amount,
//            ST_DEPOSIT = 0,
//            ST_WITHDRAWL = amount
//        };

//        db.Savings_Transaction.Add(transaction);
//        db.SaveChanges();

//        return $"Amount of Rs.{amount} withdrawn successfully from Customer ID {customerId}.";
//    }
//}


