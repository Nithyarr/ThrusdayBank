﻿using BankModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace BankServices
{
    public class CustomerService
    {
        private readonly BankDBEntities db = new BankDBEntities();
        //public Fixed_Deposit_Account GetFDAccountById(int fdId)
        //{
        //    return db.Fixed_Deposit_Account
        //             .FirstOrDefault(f => f.ID == fdId);
        //}

        //// Foreclose FD account
        //public string ForecloseFDAccount(int fdId)
        //{
        //    var fd = GetFDAccountById(fdId);
        //    if (fd == null)
        //        return "FD Account not found or does not belong to this customer.";

        //    // Calculate payout till date (preclosure)
        //    decimal payout = CalculatePreclosureAmount(fd);

        //    // Record transaction
        //    var transaction = new Fixed_Deposit_Transaction
        //    {
        //        FT_ACCOUNT_ID = fd.ID,
        //        FT_AMOUNT = fd.AMOUNT,
        //        FT_PRECLOSURE = payout,
        //        FT_TRANSACTION_DATE = DateTime.Now
        //    };
        //    db.Fixed_Deposit_Transaction.Add(transaction);

        //    // Remove FD account
        //    db.Fixed_Deposit_Account.Remove(fd);
        //    db.SaveChanges();

        //    return $"FD Account foreclosed successfully! Payout: {payout:C}";
        //}

        //// Simple preclosure calculation
        //private decimal CalculatePreclosureAmount(Fixed_Deposit_Account fd)
        //{
        //    var days = (DateTime.Now - fd.START_DATE).Days;
        //    var interest = fd.AMOUNT * (fd.FD_ROI/ 100) * days / 365;
        //    return (decimal)(fd.AMOUNT + interest);
        //}

        //// Get all FDs for a customer
        //public List<Fixed_Deposit_Account> GetFDAccountsByCustomer(int customerId)
        //{
        //    return db.Fixed_Deposit_Account.Where(f => f.ID == customerId).ToList();
        //}
        // Get FD account by ID
        public Fixed_Deposit_Account GetFDAccountById(int fdId)
        {
            return db.Fixed_Deposit_Account.FirstOrDefault(f => f.ID == fdId);
        }

        // Foreclose FD account
        public string ForecloseFDAccount(int fdId)
        {
            var fd = GetFDAccountById(fdId);
            if (fd == null)
                return "FD Account not found.";

            // Calculate payout
            decimal payout = CalculatePreclosureAmount(fd);

            // Record transaction
            var transaction = new Fixed_Deposit_Transaction
            {
                FT_ACCOUNT_ID = fd.ID,
                FT_AMOUNT = fd.AMOUNT,
                FT_PRECLOSURE = payout,
                FT_TRANSACTION_DATE = DateTime.Now
            };
            db.Fixed_Deposit_Transaction.Add(transaction);

            // Remove FD account
            db.Fixed_Deposit_Account.Remove(fd);
            db.SaveChanges();

            return $"FD Account foreclosed successfully! Payout: {payout:C}";
        }

        // Preclosure calculation
        private decimal CalculatePreclosureAmount(Fixed_Deposit_Account fd)
        {
            var days = (DateTime.Now - fd.START_DATE).Days;
            var interest = fd.AMOUNT * (fd.FD_ROI / 100) * days / 365;
            return (decimal)(fd.AMOUNT + interest);
        }

        // Get all FDs for a customer
        public List<Fixed_Deposit_Account> GetFDAccountsByCustomer(int customerId)
        {
            return db.Fixed_Deposit_Account.Where(f => f.C_ID == customerId).ToList();
        }

        //
        public Savings_Account GetAccountByCustomerId(int customerId)
        {
            return db.Savings_Account.FirstOrDefault(a => a.C_ID == customerId);
        }

       
    }

}


