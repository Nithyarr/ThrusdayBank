﻿using BankingApp.Models.ViewModel;
using BankModel;
using BankModel.ViewModel;
using BankServices;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Services.Description;

namespace BankingApp.Controllers
{
    public class CustomerController : Controller
    {
        private readonly BankDBEntities _dbContext = new BankDBEntities();
        private readonly CustomerService service = new CustomerService();
        private readonly TransactionService _transactionService = new TransactionService();


        public CustomerController()
        {
            _dbContext = new BankDBEntities();
            service = new CustomerService();
            
        }


        [HttpGet]

        public ActionResult CustomerHome()
        {

            if (Session["ReferenceId"] == null)
                return RedirectToAction("Login", "Home");

            string referenceId = Session["ReferenceId"].ToString();
            ViewBag.ReferenceId = referenceId;

            return View();
        }
        [HttpPost]
        public ActionResult CustomerHome(string customerId)
        {
            var customer = _dbContext.Customers.FirstOrDefault(c => c.C_ID == customerId);

            if (customer == null)
            {
                return HttpNotFound("Customer not found");
            }


            ViewBag.Customer = customer;

            return View();
        }

        [HttpGet]
        public ActionResult Deposit()
        {
            
            return View();

        }

        [HttpPost]
        public ActionResult Deposit(decimal amount)
        {

            string id = Session["ReferenceId"].ToString(); 

            ViewBag.ReferenceId = id;
            if (Session["ReferenceId"] == null)
            {
                ViewBag.Message = "Session expired. Please log in again.";
                return View();
            }

            string customerId = Session["ReferenceId"].ToString();
            string result = _transactionService.Deposit(customerId, amount);

            ViewBag.Message = result;
            return View();
        }

        [HttpGet]
        public ActionResult Withdraw()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Withdraw(decimal amount)
        {
            // Check if session exists
            if (Session["ReferenceId"] == null)
            {
                ViewBag.Message = "Session expired. Please log in again.";
                return View();
            }

            string customerId = Session["ReferenceId"].ToString();

            // Fetch customer account first
            var customer = _transactionService.GetCustomerByCId(customerId);
            if (customer == null)
            {
                ViewBag.Message = "Customer not found.";
                return View();
            }

            var account = _transactionService.GetAccountByCustomerId(customer.ID);
            if (account == null)
            {
                ViewBag.Message = "Savings account not found.";
                return View();
            }

            // Check for minimum balance
            if (account.BALANCE - amount < 1000)
            {
                ViewBag.Message = $"Withdrawal failed. Minimum balance of Rs.1000 must be maintained. Current balance: Rs.{account.BALANCE}";
                return View();
            }

            // Perform withdrawal
            string result = _transactionService.Withdraw(customerId, amount);

            ViewBag.Message = result;
            return View();
        }
        [HttpGet]
        public ActionResult TransactionHistory()
        {
            // Check session
            if (Session["ReferenceId"] == null)
            {
                ViewBag.Message = "Session expired. Please log in again.";
                return RedirectToAction("Login", "Account");
            }

            string customerId = Session["ReferenceId"].ToString();

            // Fetch customer
            var customer = _transactionService.GetCustomerByCId(customerId);
            if (customer == null)
            {
                ViewBag.Message = "Customer not found.";
                return View(new List<Savings_Transaction>());
            }

            // Fetch all accounts for this customer
            var accounts = _transactionService.GetAccountsByCustomerId(customer.ID);

            // Fetch all transactions for these accounts
            var transactions = new List<Savings_Transaction>();
            foreach (var account in accounts)
            {
                transactions.AddRange(_transactionService.GetTransactionsByAccountId(account.ID));
            }

            // Order by date descending
            transactions = transactions.OrderByDescending(t => t.ST_TRANSACTION_DATE).ToList();

            return View(transactions);
        }
        //===========================
        //FD ACCOUNT 
        //=======================
        [HttpGet]
        public ActionResult ForecloseFD()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ForecloseFD(string fdAccountId)
        {
            // Session check
            if (Session["ReferenceId"] == null)
            {
                ViewBag.Message = "Session expired. Please log in again.";
                return RedirectToAction("Login", "Account");
            }

            if (string.IsNullOrWhiteSpace(fdAccountId))
            {
                ViewBag.Message = "Please enter FD Account ID.";
                return View();
            }

            string customerId = Session["ReferenceId"].ToString();

            // Call service to foreclose FD for this customer
            string result = _transactionService.ForecloseFDByCustomer(customerId, fdAccountId);

            ViewBag.Message = result;
            return View();
        }


    }
}


    


    
