﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankModel;
namespace BankServices
{
    public class AuthService
    {
        private readonly BankDBEntities dc;

        public AuthService()
        {
            dc = new BankDBEntities();
        }


        // Register Customer
        public string RegisterCustomer(string name, string dob, string pan, string mobile,
                                       string email, decimal salary, string address, string gender, string password)
        {
            var existing = dc.Customers.FirstOrDefault(c => c.C_EMAIL == email);
            if (existing != null)
                return "Customer already registered!";

            var cust = new Customer
            {
                C_NAME = name,
                C_DOB = DateTime.Parse(dob),
                C_PAN = pan,
                C_MOBILE = mobile,
                C_EMAIL = email,
                C_SALARY = salary,
                C_ADDRESS = address,
                C_GENDER = gender,
                C_PASSWORD = password
            };

            dc.Customers.Add(cust);
            dc.SaveChanges();

            var login = new Login
            {
                USERNAME = cust.C_NAME,
                PASSWORD = password,
                ROLE = "Customer",
                Reference_ID = cust.C_ID
            };

            dc.Logins.Add(login);
            dc.SaveChanges();

            return $"Registration successful! Customer ID: {cust.C_ID}";
        }

        // Register Employee
        public string RegisterEmployee(string name, DateTime dob, int deptId, string pan, string mobile,
                                       string email, string address, string gender, string password)
        {
            if (string.IsNullOrWhiteSpace(mobile) || mobile.Length != 10 || !mobile.All(char.IsDigit))
                return "Invalid mobile number. Must be exactly 10 digits.";

            var existing = dc.Employees.FirstOrDefault(e => e.E_Email == email);
            if (existing != null)
                return "Employee already exists.";

            var employee = new Employee
            {
                Employee_Name = name,
                E_Department_ID = deptId,
                E_Mobile = mobile,
                E_Email = email,
                E_DOB = dob,
                E_Gender = gender,
                E_Address = address,
                E_PAN = pan,
                E_PASSWORD = password
            };

            dc.Employees.Add(employee);
            dc.SaveChanges();

            var login = new Login
            {
                USERNAME = name,
                PASSWORD = password,
                ROLE = "Employee",
                Reference_ID = employee.E_ID
            };
            dc.Logins.Add(login);
            dc.SaveChanges();

            return "Employee registered successfully.";
        }

        // Login method returns tuple with role info
        public (bool Success, string Message, string Role, string ReferenceId) Login(string username, string password)
        {
            var user = dc.Logins.FirstOrDefault(u => u.USERNAME == username && u.PASSWORD == password);
            if (user == null)
                return (false, "Invalid username or password.", null, null);

            return (true, $"Welcome {user.USERNAME}!", user.ROLE, user.Reference_ID);
        }
        
        


    }

}
