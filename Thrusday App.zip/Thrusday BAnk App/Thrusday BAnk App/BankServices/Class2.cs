﻿using BankModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace BankServices
{
    public class ManagerService
    {

        private readonly BankDBEntities db;

        public ManagerService(BankDBEntities context)
        {
            db = context;
        }

        public Customer GetCustomerByPan(string pan)

        {

            return db.Customers.FirstOrDefault(c => c.C_PAN == pan);

        }


        public Customer AddCustomer(Customer customer)
        {
            db.Customers.Add(customer);
            db.SaveChanges();
            return customer;
        }

        public Savings_Account AddSavingsAccount(int customerId, decimal balance)
        {
            var account = new Savings_Account
            {
                C_ID = customerId,
                BALANCE = balance
            };
            db.Savings_Account.Add(account);
            db.SaveChanges();
            return account;
        }

        public string CloseAccount(string pan)
        {
            using (var db = new BankDBEntities())
            {
                if (string.IsNullOrWhiteSpace(pan))
                    return "PAN number is required.";

                var customer = db.Customers.FirstOrDefault(c => c.C_PAN == pan);
                if (customer == null)
                    return $"No customer found with PAN: {pan}";

                var account = db.Savings_Account.FirstOrDefault(a => a.C_ID == customer.ID);
                if (account == null)
                    return $"No savings account found for customer with PAN: {pan}";
                var login = db.Logins.FirstOrDefault(l => l.Reference_ID == customer.C_ID  && l.ROLE == "Customer");
                if (login != null)
                {
                    db.Logins.Remove(login);

                }
                db.Customers.Remove(customer);
                db.Savings_Account.Remove(account);
                db.SaveChanges();


                return $"Savings account {account.SA_ACCOUNT_ID} for customer {customer.C_NAME} has been closed successfully.";
            }
        }
        public string RemoveEmployee(string eid)
        {
            using (var db = new BankDBEntities())
            {
                var employee = db.Employees.FirstOrDefault(e => e.E_ID == eid);
                if (employee == null)
                    return $"No employee found with ID: {eid}";

                // Optional: Remove login associated with employee
                var login = db.Logins.FirstOrDefault(l => l.Reference_ID == employee.E_ID && l.ROLE == "Employee");
                if (login != null)
                {
                    db.Logins.Remove(login);
                }

                db.Employees.Remove(employee);
                db.SaveChanges();

                return $"Employee {employee.Employee_Name} with ID {employee.E_ID} has been removed successfully.";
            }
        }
        public Home_Loan_Account AddLoanAccount(int customerId, decimal loanAmount, DateTime startDate, int tenure, decimal roi, decimal emi, string status)
        {
            var loanAccount = new Home_Loan_Account
            {
                C_ID = customerId,
                LOAN_AMOUNT = loanAmount,
                START_DATE = startDate,
                TENURE = tenure,
                LN_ROI = roi,
                EMI = emi,
                STATUS = status
            };
            db.Home_Loan_Account.Add(loanAccount);
            db.SaveChanges();
            return loanAccount;
        }

    }
}
