﻿using BankingApp.Models.ViewModel;
using BankModel;
using BankModel.ViewModel;
using BankServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Services.Description;

namespace BankingApp.Controllers
{
    public class CustomerController : Controller
    {
        private readonly BankDBEntities _dbContext = new BankDBEntities();
        private readonly CustomerService service = new CustomerService();
      


        public CustomerController()
        {
            _dbContext = new BankDBEntities();
            service = new CustomerService();
            
        }


        [HttpGet]

        public ActionResult CustomerHome()
        {


            //ViewBag.FDs = service.GetFDAccountsByCustomer(customerId);
            return View();
        }
        [HttpPost]
        public ActionResult CustomerHome(string customerId)
        {
            var customer = _dbContext.Customers.FirstOrDefault(c => c.C_ID == customerId);

            if (customer == null)
            {
                return HttpNotFound("Customer not found");
            }


            ViewBag.Customer = customer;

            return View();
        }


        //[HttpPost]
        //public ActionResult ForecloseFD(int fdId, string confirm)
        //{
        //    if (confirm == "Yes")
        //    {
        //        ViewBag.Message = service.ForecloseFDAccount(fdId);
        //    }
        //    else
        //    {
        //        ViewBag.Message = "FD foreclosure cancelled.";
        //    }

        //    var customer = _dbContext.Customers.FirstOrDefault(c => c.ID == fdId);
        //    ViewBag.Customer = customer;
        //    ViewBag.FDs = service.GetFDAccountsByCustomer(fdId);
        //    return View("CustomerHome");
        //}
        [HttpPost]
        public ActionResult ForecloseFD(int fdId, int customerId, string confirm)
        {
            if (confirm == "Yes")
            {
                ViewBag.Message = service.ForecloseFDAccount(fdId);  // service handles preclosure & transaction
            }
            else
            {
                ViewBag.Message = "FD foreclosure cancelled.";
            }

            // Fetch updated customer and FD list
            var customer = _dbContext.Customers.FirstOrDefault(c => c.ID == customerId);
            ViewBag.Customer = customer;
            ViewBag.FDs = service.GetFDAccountsByCustomer(customerId);

            return View("CustomerHome");
        }




        //// GET: Transaction Page
        //[HttpGet]
        //public ActionResult Transaction()
        //{
        //    return View();
        //}

        //// POST: Deposit
        //[HttpPost]
        //public ActionResult Deposit(int customerId, decimal amount)
        //{
        //    string result = _transactionService.Deposit(customerId, amount);
        //    ViewBag.Message = result;
        //    return View("Transaction");
        //}

        //// POST: Withdraw
        //[HttpPost]
        //public ActionResult Withdraw(int customerId, decimal amount)
        //{
        //    string result = _transactionService.Withdraw(customerId, amount);
        //    ViewBag.Message = result;
        //    return View("Transaction");
        //}
        //    [HttpGet]
        //    public ActionResult Deposit(string id)
        //    {
        //        ViewBag.CustomerId = id;
        //        return View();
        //    }

        //    [HttpPost]
        //    public ActionResult Deposit(int customerId, decimal amount)
        //    {
        //        string message = _transactionService.Deposit(customerId, amount);
        //        ViewBag.Message = message;
        //        ViewBag.CustomerId = customerId;
        //        return View();
        //    }

        //    [HttpGet]
        //    public ActionResult Withdraw(int id)
        //    {
        //        ViewBag.CustomerId = id;
        //        return View();
        //    }

        //    [HttpPost]
        //    public ActionResult Withdraw(int customerId, decimal amount)
        //    {
        //        string message = _transactionService.Withdraw(customerId, amount);
        //        ViewBag.Message = message;
        //        ViewBag.CustomerId = customerId;
        //        return View();
        //    }


        //}

        
        [HttpGet]
        public ActionResult Deposit() => View(new CustomerTransactionsViewModel());

        [HttpPost]
     
        public ActionResult Deposit(CustomerTransactionsViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            Session["CustomerId"] = model.CustomerId;
            int customerId = Convert.ToInt32(Session["CustomerId"]);
            model.Message = service.Deposit(customerId, model.Amount);

            var updatedAccount = service.GetAccountByCustomerId(customerId);
            model.Balance = (decimal)updatedAccount.BALANCE;

            return View(model);
        }

        [HttpGet]
        public ActionResult Withdraw() => View(new CustomerTransactionsViewModel());

        [HttpPost]
       
        public ActionResult Withdraw(CustomerTransactionsViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            int customerId = Convert.ToInt32(Session["CustomerId"]);
            model.Message = service.Withdraw(customerId, model.Amount);

            var updatedAccount = service.GetAccountByCustomerId(customerId);
            model.Balance = (decimal)updatedAccount.BALANCE;

            return View(model);
        }
    }
}

    


    
